package com.example.kebunhewan.Models

data class DataModel (
    val gambar : Int,
    val nama : String,
    val keterangan : String
)